import java.util.Scanner;

public class DescendingParser {

    private static String input;
    private static int index;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez une chaîne : ");
        input = scanner.nextLine();
        index = 0;

        if (S() && index == input.length()) {
            System.out.println("La chaîne est acceptée.");
        } else {
            System.out.println("La chaîne est rejetée.");
        }

        scanner.close();
    }

    private static boolean S() {
        if (match('b')) {
            if (S()) {
                return match('b');
            }
            return false;
        } else if (match('c')) {
            if (A()) {
                return match('c');
            }
            return false;
        }
        return false;
    }

    private static boolean A() {
        if (match('b')) {
            if (A()) {
                return A();
            }
            return false;
        } else if (match('c')) {
            if (A() && match('S') && match('A') && match('b')) {
                return true;
            }
            return false;
        } else if (match('d')) {
            return match('c') && match('b');
        }
        return false;
    }

    private static boolean match(char expected) {
        if (index < input.length() && input.charAt(index) == expected) {
            index++;
            return true;
        }
        return false;
    }
}
